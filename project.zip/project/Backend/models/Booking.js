import mongoose, {Schema} from 'mongoose';

const BookingSchema = mongoose.Schema(
    {   
        Email:{
            type: String,
            required: true,
        },
        From_Station: {
            type: String,
            required: true,
        },
        To_Station: {
            type: String,
            required: true
        },
        Count: {
            type: Number,
            required: true,
        },
        Class: {
            type: String,
            required: true,
        },
        Type: {
            type: String,
            required: true,
        },
        Payment_mode: {
            type: String,
            required: true,
        },
        Fare:{
            type: String,
            required: true,
        },
        Status:{
            type:String,
        }
    },
    {
        timestamps: true
    }
);

export default mongoose.model("Booking", BookingSchema);