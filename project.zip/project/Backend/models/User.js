import mongoose from "mongoose"

const userSchema = mongoose.Schema({
    Name:{
        type: String,
        required: true
    },
    Email: {
        type: String,
        required: true,
    },
    Mobile_number:{
        type: Number,
        required: true
    },
    Password: {
        type: String,
        required: true
    },
},
    {
        timestamps: true
    }
)


export default mongoose.model("User", userSchema)