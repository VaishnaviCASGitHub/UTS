import express from 'express';
import mongoose from 'mongoose';
import cors from 'cors';
import authRoute from './routes/auth.js';
import bookingRoute from './routes/booking.js';
import showRoute from './routes/show.js';
import logger from './logger.js';
import cookieParser from 'cookie-parser';

const PORT = 8800;
const app = express();
app.use(express.json());
app.use(cookieParser());
app.use(cors({
    origin: 'http://localhost:4200',
    credentials: true
}));
app.use((req, res, next) => {
    logger.info(`${req.method} ${req.url}`);
    next();
});


app.use("/api/auth", authRoute);
app.use("/api/show", showRoute);
app.use("/api/booking", bookingRoute);


//Response Handler Middleware

app.use((obj, req, res, next)=>{
    const statusCode = obj.status || 500;
    const message = obj.message || "Something went wrong!";
    return res.status(statusCode).json({
        success: [200,201,204].some(a=> a === obj.status) ? true : false,
        status: statusCode,
        message: message,
        data: obj.data
    });
});

const connectMongoDB = async () => {
    try {
        await mongoose.connect("mongodb://127.0.0.1:27017/UTS");
        console.log("Connected to Database!");
    } catch (error) {
        throw error;
    }
}
app.listen(PORT, ()=>{
    connectMongoDB();
    console.log(`Connected to Backend on PORT ${PORT}!`);
});