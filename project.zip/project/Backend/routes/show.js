import express from 'express';
import { showTicket } from '../controllers/show.controller.js';
import { cancelTicket } from '../controllers/show.controller.js'

const router = express.Router();
router.post("/show-ticket",showTicket)
router.post("/cancel",cancelTicket)

export default router;