import Booking from "../models/Booking.js";
import logger from "../logger.js";

export const bookingRegister = async (req, res, next) =>
{   
    try{
    const newUser = new Booking({
        Email:req.body.id,
        From_Station: req.body.selectedFrom,
        To_Station:req.body.selectedTo,
        Count:req.body.passengers,
        Class:req.body.selectedClass,
        Type:req.body.selectedType,
        Payment_mode:req.body.selectedPay,
        Fare:req.body.fare,
        Status:"Booked"
    });
    await newUser.save();
    console.log("--------------------------------------")
    return res.status(200).json("Ticket booked successfully!");
}
catch(error){
    console.log(error)
}
}
