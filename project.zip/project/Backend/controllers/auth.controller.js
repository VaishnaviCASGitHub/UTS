import User from "../models/User.js";
import bcrypt from "bcryptjs";
import logger from "../logger.js";
export const register = async (req, res, next) =>
{   
    try{
    const reguser= await User.findOne({ Email: req.body.mail});
     if(reguser){
        return res.status(404).json("Email ID already exists");
     }
     else{
        const salt = await bcrypt.genSalt(10);
        const hashPassword = await bcrypt.hash(req.body.password, salt);
        const newUser = new User({
            
            Name: req.body.username,
            Email: req.body.mail,
            Mobile_number:req.body.contactno,
            Password: hashPassword    
        });
        await newUser.save();
        logger.info(`User ${req.body.mail} registered`);
        return res.status(200).json("User Registered Successfully!");
     }
    }
     catch (error) {
        console.error(error);
        return res.status(500).json("Something went wrong!");
    }
}

export const login = async (req, res, next) =>
{
    try
    { 
        const user = await User.findOne({ Email: req.body.em })
        if(!user)
        {   
            console.log("Error occurred");
            return res.status(400).json("User not found!");
        }
        const isPasswordCorrect = await bcrypt.compare(req.body.password, user.Password);
        if (!isPasswordCorrect)
        {
            return res.status(400).json("Password is incorrect!");
        }
        logger.info(`User ${req.body.em} logged in`);
        res.cookie('sessionID', user._id, { httpOnly: true, maxAge: 15 * 60 * 1000  });
        return res.status(200).json({
                status: 200,
                message: "Login Success",
                data: user
            })
            
    } catch (error)
    {   
        console.error(error);
        return res.status(500).json("Something went wrong!");
    }
}