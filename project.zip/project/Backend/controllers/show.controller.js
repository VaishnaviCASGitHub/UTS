import Booking from "../models/Booking.js";
import logger from "../logger.js";

export const showTicket= async(req,res)=>{
    try{
        const showTicketContainer = await Booking.find({Email:req.body.userMail})
        console.log(req.body, showTicketContainer)
        if(!showTicketContainer){
            return res.status(404).json({message:'Ticket Not found'})
        }
        return res.status(200).json({status:200,message:'ticket',data:showTicketContainer})
       
    }
    catch(error){
        return res.status(500).json({status:500,message:'Internal Server Error'})
    }
}
export const cancelTicket=async(req,res,next)=>{
    try {
        const id = req.body.ticketId;
        const updatedTicket = await Booking.findByIdAndUpdate(id, { Status: 'Cancelled' }, { new: true });
        const resultant={updatedTicket}
        console.log(resultant)
        const finalres = await Booking.find({Email:req.body.userMail})
        res.json(finalres);
      } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Internal server error' });
      }
}
