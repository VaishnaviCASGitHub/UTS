import { CommonModule, DatePipe } from '@angular/common';
import { Component,OnInit } from '@angular/core';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule, AbstractControl } from '@angular/forms';
import { Router } from '@angular/router';
import { FormBuilder } from '@angular/forms';
import { BookingService } from '../booking.service';
import { Validators} from '@angular/forms';
import { FooterComponent } from '../footer/footer.component';
import { UsersService } from '../users.service';
import { PaymentComponent } from '../payment/payment.component';
@Component({
  selector: 'app-book-ticket',
  imports: [FooterComponent, PaymentComponent, BookTicketComponent,FormsModule, ReactiveFormsModule, CommonModule],
  standalone: true,
  templateUrl: './book-ticket.component.html',
  styleUrl: './book-ticket.component.css',
  providers:[DatePipe]
})
export class BookTicketComponent implements OnInit {
  // Initializations
  showTooltip = false; // Tooltip for date
  showTooltips = false; // Tooltip for To station
  calculatedFare: any; // Fare
  fromplaceholder:string="Select from.." // Placeholder for from
  toplaceholder:string="Select to.." // Placeholder for to
  classtypeplaceholder:string="Select Class.." // Placeholder for class
  typeplaceholder:string="Select Type.."; // Placeholder for type
  isFormSubmitted:boolean=false;


  // Constructor for Date
  constructor(private bookingservice: BookingService, private usersservice: UsersService, private routes:Router, private fb: FormBuilder){
  }

  // Book form group 
  bookForm = new FormGroup({
    selectedfrom: new FormControl(''),
    selectedto: new FormControl(''),
    passengers: new FormControl(''),
    selectedclass: new FormControl(''),
    selectedtype: new FormControl(''),
    calculatedFare: new FormControl('')
  })
  
  bookingPassengers = {
    selectedfrom:'',
    selectedto:'',
    passengers:'',
    selectedclass: '',
    selectedtype: '',
    calculatedFare: ''
};

  // Options for from station
  selectedfromoptions = [
    { name: "Chennai Beach Junction", value: "beach" },
    { name: "Chennai Fort", value: "fort" },
    { name: "Park Town", value: "park" },
    { name: "Chintadaripet", value: "chinta" },
    { name: "Tiruvallikeni", value: "tiruvalli" },
    { name: "Chepauk", value: "chepauk" },
    { name: "Light House", value: "lighthouse" },
    { name: "Thirumayilai", value: "thirumai" },
    { name: "Mandaveli", value: "manda" },
    { name: "Greenways Road", value: "greenways" },
    { name: "Kotturpuram", value: "kottur" },
    { name: "Kasturba Nagar", value: "kastur" },
    { name: "Tiruvanmiyur", value: "tiruvanmiyur" },
    { name: "Taramani", value: "taramani" },
    { name: "Perungudi", value: "perungudi" },
    { name: "Velachery", value: "velacherystn" }
  ]

  // Options for to station
  selectedtooptions = [
    { name: "Chennai Beach Junction", value: "beach" },
    { name: "Chennai Fort", value: "fort" },
    { name: "Park Town", value: "park" },
    { name: "Chintadaripet", value: "chinta" },
    { name: "Tiruvallikeni", value: "tiruvalli" },
    { name: "Chepauk", value: "chepauk" },
    { name: "Light House", value: "lighthouse" },
    { name: "Thirumayilai", value: "thirumai" },
    { name: "Mandaveli", value: "manda" },
    { name: "Greenways Road", value: "greenways" },
    { name: "Kotturpuram", value: "kottur" },
    { name: "Kasturba Nagar", value: "kastur" },
    { name: "Tiruvanmiyur", value: "tiruvanmiyur" },
    { name: "Taramani", value: "taramani" },
    { name: "Perungudi", value: "perungudi" },
    { name: "Velachery", value: "velacherystn" }
  ]

  // Options for class
  selectedclassoptions = [
    { name: "Second Class(II)", value: "second"},
    { name: "First Class(I)", value: "first" }
  ]

  // Options for type
  typeoptions = [
    { name: "Journey", value: "journeyclass" },
    { name: "Return", value: "returnclass" }
  ]
  
  // Creating booking object
  bookingObj = [
    { selectedfrom: 'Velachery',selectedto: 'Park Town', passengers: 2, selectedclass:'Second(II)',selectedtype:'Journey'},
    { selectedfrom: 'Velachery',selectedto: 'Park Town', passengers: 2, selectedclass:'Second(II)',selectedtype:'Journey'}
      
  ];

  // BookTicket method
  BookTicket() {
    this.isFormSubmitted=true;
    const from = this.bookForm.value.selectedfrom;
    const to = this.bookForm.value.selectedto;
    const classes = this.bookForm.value.selectedclass;
    const types = this.bookForm.value.selectedtype;
    const pas = this.bookForm.value.passengers;
    if (from && to && classes && types && pas) {
      this.calculatedFare = this.bookingservice.calculateFare(from, to, classes, types, pas);
    }
    setTimeout(() => {
      this.routes.navigate(['payment']);
    }, 1000);
    

    // Storing the selected values in form
    let userForm ={
      'selectedFrom':this.bookForm.value.selectedfrom,
      'selectedTo':this.bookForm.value.selectedto,
      'passengers':this.bookForm.value.passengers,
      'selectedClass':this.bookForm.value.selectedclass,
      'selectedType':this.bookForm.value.selectedtype
    }
    // Storing Fare in service
    this.bookingservice.postForm(userForm,this.calculatedFare)
  }
ngOnInit(): void {
  if(this.usersservice.isLoggedIn()==true){
    this.fromplaceholder,
    this.toplaceholder,
    this.classtypeplaceholder,
    this.typeplaceholder
    this.bookForm = this.fb.group({
      selectedfrom: ['', Validators.required],
      selectedto: ['', Validators.required],
      passengers: ['', [Validators.required, 1, Validators.min(1), Validators.max(10)]],
      selectedclass:['', Validators.required], 
      selectedtype:['', Validators.required],
      calculatedFare:['', Validators.required]
    }, { validators: this.checkStations });
  }
  else{
    this.routes.navigate(["/login"])
  }
}
  //  Tooltips for mousenter method
  onMouseEnter() {
    this.showTooltip = true;
    this.showTooltips=true;
  }

  //  Tooltips for mouseleave method
  onMouseLeave() {
    this.showTooltip = false;
    this.showTooltips=false;
  }
  

  checkStations(group: FormGroup): { [key: string]: boolean } | null {
  const selectedfrom = group.get('selectedfrom')?.value;
  const selectedto = group.get('selectedto')?.value;
  return selectedfrom && selectedto && selectedfrom === selectedto ? { 'sameStations': true } : null;
}
}
