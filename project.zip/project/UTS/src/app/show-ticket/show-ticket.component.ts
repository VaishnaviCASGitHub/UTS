import { CommonModule } from '@angular/common';
import { Component, OnInit} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BookTicketComponent } from '../book-ticket/book-ticket.component';
import { BookingService } from '../booking.service';
import { FooterComponent } from '../footer/footer.component';
import { PaymentComponent } from '../payment/payment.component';

@Component({
  selector: 'app-show-ticket',
  standalone: true,
  imports: [BookTicketComponent, CommonModule,FormsModule, FooterComponent],
  templateUrl: './show-ticket.component.html',
  styleUrl: './show-ticket.component.css'
})
export class ShowTicketComponent implements OnInit{

// Initialization
 formList:any=[];

 // Constructor
 constructor(private bookingservice: BookingService){}
     
ngOnInit(): void {
  this.bookingservice.showForm().subscribe(
    result=>{
      this.formList=result
      console.log(result)
    }
  )
}

// Getting time
getCurrentTime(): Date {
  return new Date();
}
}
