import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { Router, RouterLink, RouterOutlet } from '@angular/router';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { UsersService } from '../users.service';
import { FooterComponent } from '../footer/footer.component';
 
@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, RouterOutlet, RouterLink, ReactiveFormsModule, FooterComponent],
  templateUrl: './register.component.html',
  styleUrl: './register.component.css'
})
export class RegisterComponent {
  declare $: any;
  showTooltip = false;
  registrationForm = new FormGroup({
    username: new FormControl('', Validators.pattern("^[aA-zZ]+$")),
    mail: new FormControl('', Validators.pattern("^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$")),
    password: new FormControl('', Validators.pattern("^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$")),
    cpassword: new FormControl('', Validators.pattern("^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$")),
    location: new FormControl('', Validators.pattern("^[aA-zZ]+$")),
    contactno: new FormControl('', Validators.required)
  })

  constructor(private usersservice: UsersService, private router:Router){}
  ngAfterViewInit() {
    $(function () {
      $('[data-toggle="popover"]').popover()
    })
  }
  
  onSubmit(){
    console.log(this.registrationForm.value)
    const email=this.registrationForm.value.mail;
    let user:any= {
      username:this.registrationForm.value.username!,
      mail:this.registrationForm.value.mail!,
      password: this.registrationForm.value.password!,
      cpassword:this.registrationForm.value.cpassword!,
      location:this.registrationForm.value.location!,
      contactno:this.registrationForm.value.contactno!,
      }
    this.usersservice.register(user).subscribe(
      (result:any) => {
        if(result){
          alert(`You have successfully registered with ${email}`)
          this.router.navigate(['login'])
        }
        else{
          alert("Registration not successfull")
          this.router.navigate(['register'])
        }
      }
    )
    }
    checkPasswordRequirements() {
      const passwordControl = this.registrationForm.get('password');
      if (passwordControl) {
        const password: any = passwordControl.value;
        return {
          uppercase: /[A-Z]/.test(password),
          lowercase: /[a-z]/.test(password),
          digit: /\d/.test(password),
          specialChar: /[!@#$%^&*]/.test(password),
          minLength: password.length >= 8
        };
      }
      return null;
    }   
}
 