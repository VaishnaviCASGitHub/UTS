import { Injectable } from '@angular/core';
import { of } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class BookingService {
  // Initializations
  constructor() { }
// Book ticket - Rates
private fareRates : { [key: string]: number } = {
  'Chennai Beach Junction': 20,
  'Chennai Fort': 19,
  'Park Town': 18,
  'Chintadaripet': 17,
  'Tiruvallikeni': 16,
  'Chepauk': 15,
  'Light House': 14,
  'Thirumayilai': 13,
  'Mandaveli': 12,
  'Greenways Road': 11,
  'Kotturpuram': 10,
  'Kasturba Nagar': 9,
  'Tiruvanmiyur': 8,
  'Taramani': 7,
  'Perungudi': 6,
  'Velachery': 5,
  'Return':5,
  'First Class(I)':5,
  'Journey':0,
  'Second Class(II)':0
};

  // Book ticket - Fare calculation
    calculateFare(from: string, to: string, classes: string, types: string, pas: any): number {
    let totalAmount :any
    let passengerRate=0
    const fromRate = this.fareRates[from];
    const toRate = this.fareRates[to];
    const distanceFare = (Math.abs(toRate - fromRate )*pas); 
    
    if(types=="Return" || classes=="First Class(I)"){
      passengerRate = pas*3
    }

    totalAmount = passengerRate + distanceFare
    if(pas>5){
      totalAmount =totalAmount*0.9
    }
    return totalAmount;
  }

  // Empty array 
  forms:any=[
  
  ]

  postForm(userForm:any,fare:any){
    console.log(userForm)
    this.forms.push(userForm)
    userForm['id']=sessionStorage.getItem('uid')
    userForm['fare']=fare
  }

  // Pushing form into ShowUserForms
  showForm()
  {
    let showUserForms:any[]=[]
    console.log(this.forms, sessionStorage.getItem('uid'))
    for(let form of this.forms)
    {
      console.log(form)
      if(form.id == sessionStorage.getItem('uid')){
        showUserForms.push(form)
      }
    }
    return of (showUserForms)
  }
}
  
