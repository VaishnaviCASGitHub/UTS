import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { Router, RouterLink, RouterModule, RouterOutlet } from '@angular/router';
import { UsersService } from '../users.service';
import { FooterComponent } from '../footer/footer.component'
 
@Component({
  selector: 'app-login',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule, RouterModule, RouterOutlet, RouterLink, FooterComponent],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
 
 // Login form group
  loginForm = new FormGroup({
    em: new FormControl(''),
    password: new FormControl('')
  })
 // Constructor
  constructor(private usersservice: UsersService, private router: Router){}
 // Onsubmit form
  onSubmit(){
    console.log(this.loginForm.value)
 
    let status: any;
    this.usersservice.login(this.loginForm.value.em,this.loginForm.value.password).subscribe(
      result => {
        status = result;
        let umail: any = this.loginForm.value.em;
        if(status==true){
          sessionStorage.setItem("loggedIn", "true")
          sessionStorage.setItem("uid", umail)
          this.router.navigate([''])
          alert(`Logged in with ${umail}`)
        }
        else{
          alert("Wrong Credentials")
          this.router.navigate(['login'])
        }
      }
    )
 
  }
}
 