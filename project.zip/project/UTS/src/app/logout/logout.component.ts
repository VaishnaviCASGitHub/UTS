import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-logout',
  standalone: true,
  imports: [],
  templateUrl: './logout.component.html',
  styleUrl: './logout.component.css'
})
export class LogoutComponent {

  // Constructor
  constructor(private router:Router){}
  ngOnInit(): void {
    sessionStorage.setItem("loggedIn","false")
    sessionStorage.removeItem("uid")
    alert("You loggged out")
    this.router.navigate(["/login"])
  }
}
