import { Component, OnInit} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BookingService } from '../booking.service';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';

@Component({
  selector: 'app-payment',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css']
})
export class PaymentComponent implements OnInit{
  // Initialization
     formList:any=[]
     constructor(private bookingservice: BookingService, private routes: Router){}
     ngOnInit(): void {
      this.bookingservice.showForm().subscribe(
        result=>{
          this.formList=result
          console.log(result)
        }
      )
    }
    pay() {
      alert("You have successfully booked the ticket!")
      this.routes.navigate(['show-ticket']);
    }
    cancel() {
      this.routes.navigate(['book-ticket']);
    }

}