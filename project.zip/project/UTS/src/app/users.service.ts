import { Injectable } from '@angular/core';
import { of } from 'rxjs'

@Injectable({
  providedIn: 'root'
})
export class UsersService {
  constructor() { }

  // Login object
users: any=[
    {'username':'Vaishnavi','mail':'sample@gmail.com', 'password': 'Admin@123', 'location':'Chennai', 'contactno':'123456'},
    {'username':'Chandrika','mail':'sample@gmail.com', 'password': 'Admin@12345', 'location':'Chennai', 'contactno':'233312'},
  ]

  // Login 
  login(_user:any, _pwd: any){
    let flag = false;
    if(this.users != null){
      for(let user of this.users){
        if(user.mail === _user && user.password === _pwd){
          flag = true;
          this.loggedInUserEmail = user.mail;
          break
        }
      }
    }
    return of (flag);
  }

 // Register
  register(user:any){
    let flag = false;
    this.users.push(user)
    console.log(this.users)
    flag =true
    return of (flag);
  }

 // isLoggedIn
  isLoggedIn():any{
    if(typeof(sessionStorage)!=='undefined'){
    let result = sessionStorage.getItem("loggedIn")
    if(result=='true'){
      return true
    }
    else{
    return false
  }
}
  }
  
  //Displaying users mail
  loggedInUserEmail: any = null;
  getUserEmail(): any {
    if(this.users != null){
        return this.loggedInUserEmail;
    }
    else{
        return null;
    }
}
}
  
