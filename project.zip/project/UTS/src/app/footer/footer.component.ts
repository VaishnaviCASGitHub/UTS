import { Component } from '@angular/core';
import { BookTicketComponent } from '../book-ticket/book-ticket.component';

@Component({
  selector: 'app-footer',
  standalone: true,
  imports: [BookTicketComponent],
  templateUrl: './footer.component.html',
  styleUrl: './footer.component.css'
})
export class FooterComponent {

}
