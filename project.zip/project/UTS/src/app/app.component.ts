import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { BookTicketComponent } from './book-ticket/book-ticket.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { ShowTicketComponent } from './show-ticket/show-ticket.component';
import { RouterModule } from '@angular/router';
import { RouterLinkActive } from '@angular/router';
import { CommonModule } from '@angular/common';
import { UsersService } from './users.service';
@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, CommonModule, ContactUsComponent, HomeComponent, LoginComponent, RegisterComponent, ShowTicketComponent, RouterModule, RouterLinkActive, BookTicketComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  constructor(public usersservice:UsersService){}
  title = 'UTS';
}
