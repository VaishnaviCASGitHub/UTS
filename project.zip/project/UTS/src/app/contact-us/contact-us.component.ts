import { Component } from '@angular/core';
import { Router, RouterLink, RouterModule } from '@angular/router';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { FooterComponent } from '../footer/footer.component';
@Component({
  selector: 'app-contact-us',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterModule, RouterLink, RouterLink, FooterComponent],
  providers: [],
  templateUrl: './contact-us.component.html',
  styleUrl: './contact-us.component.css'
})
export class ContactUsComponent {

  // Form group 
  contactForm = new FormGroup({
      umobnum: new FormControl(''),
      uname: new FormControl(''),
      uEmail: new FormControl(''),
      uMsg: new FormControl('')
    });
     
    // Constructor
 constructor(private router:Router){}
 
    //onSubmit method

    onSubmit(){
      this.router.navigate(['/']);
    }
}
