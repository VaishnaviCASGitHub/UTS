export const apiUrls = {
    authServiceApi: 'http://localhost:8800/api/auth/',
    registerServiceApi: 'http://localhost:8800/api/booking/',
    showServiceApi: 'http://localhost:8800/api/show/'
}