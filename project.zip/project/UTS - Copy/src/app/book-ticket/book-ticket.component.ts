import { CommonModule, DatePipe } from '@angular/common';
import { Component,OnInit } from '@angular/core';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { FormBuilder } from '@angular/forms';
import { BookingService } from '../booking.service';
import Swal from 'sweetalert2';
import { FooterComponent } from '../footer/footer.component';
import { UsersService } from '../users.service';
@Component({
  selector: 'app-book-ticket',
  imports: [FooterComponent, BookTicketComponent,FormsModule, ReactiveFormsModule, CommonModule],
  standalone: true,
  templateUrl: './book-ticket.component.html',
  styleUrl: './book-ticket.component.css',
  providers:[DatePipe]
})
export class BookTicketComponent implements OnInit {
  // Initializations
  calculatedFare: any; 
  fromplaceholder:string="Select from.." 
  toplaceholder:string="Select to.." 
  classtypeplaceholder:string="Select Class.." 
  typeplaceholder:string="Select Type.."; 
  isFormSubmitted:boolean=false;
  isButtonDisabled = false;
  isEditDisabled = true;
  showPaymentContainer = false; 
  selectedPaymentMethod: string = '';
  isProcessingPayment:boolean=true;

  constructor(private bookingservice: BookingService, private usersservice: UsersService, private routes:Router, private fb: FormBuilder){
  }

  // Book form group 
  bookForm = new FormGroup({
    selectedfrom: new FormControl(''),
    selectedto: new FormControl(''),
    passengers: new FormControl(''),
    selectedclass: new FormControl(''),
    selectedtype: new FormControl(''),
    calculatedFare: new FormControl(''),
    selectedpay: new FormControl('')
  })

  // Options for from station
  selectedfromoptions = [
    { name: "Chennai Beach Junction", value: "beach" },
    { name: "Chennai Fort", value: "fort" },
    { name: "Park Town", value: "park" },
    { name: "Chintadaripet", value: "chinta" },
    { name: "Tiruvallikeni", value: "tiruvalli" },
    { name: "Chepauk", value: "chepauk" },
    { name: "Light House", value: "lighthouse" },
    { name: "Thirumayilai", value: "thirumai" },
    { name: "Mandaveli", value: "manda" },
    { name: "Greenways Road", value: "greenways" },
    { name: "Kotturpuram", value: "kottur" },
    { name: "Kasturba Nagar", value: "kastur" },
    { name: "Tiruvanmiyur", value: "tiruvanmiyur" },
    { name: "Taramani", value: "taramani" },
    { name: "Perungudi", value: "perungudi" },
    { name: "Velachery", value: "velacherystn" }
  ]

  // Options for to station
  selectedtooptions = [
    { name: "Chennai Beach Junction", value: "beach" },
    { name: "Chennai Fort", value: "fort" },
    { name: "Park Town", value: "park" },
    { name: "Chintadaripet", value: "chinta" },
    { name: "Tiruvallikeni", value: "tiruvalli" },
    { name: "Chepauk", value: "chepauk" },
    { name: "Light House", value: "lighthouse" },
    { name: "Thirumayilai", value: "thirumai" },
    { name: "Mandaveli", value: "manda" },
    { name: "Greenways Road", value: "greenways" },
    { name: "Kotturpuram", value: "kottur" },
    { name: "Kasturba Nagar", value: "kastur" },
    { name: "Tiruvanmiyur", value: "tiruvanmiyur" },
    { name: "Taramani", value: "taramani" },
    { name: "Perungudi", value: "perungudi" },
    { name: "Velachery", value: "velacherystn" }
  ]

  // Options for class
  selectedclassoptions = [
    { name: "Second Class(II)", value: "second"},
    { name: "First Class(I)", value: "first" }
  ]

  // Options for type
  typeoptions = [
    { name: "Journey", value: "journeyclass" },
    { name: "Return", value: "returnclass" }
  ]

  // BookTicket method
  BookTicket() {
    this.isFormSubmitted=true;
    this.isButtonDisabled = true;
    this.isEditDisabled = false;
    this.showPaymentContainer = true;
    const from = this.bookForm.value.selectedfrom;
    const to = this.bookForm.value.selectedto;
    const classes = this.bookForm.value.selectedclass;
    const types = this.bookForm.value.selectedtype;
    const pas = this.bookForm.value.passengers;
    if (from && to && classes && types && pas) {
      this.calculatedFare = this.bookingservice.calculateFare(from, to, classes, types, pas);
    }
  }
ngOnInit(): void {
  if(this.usersservice.isLoggedIn()==true){
    this.fromplaceholder,
    this.toplaceholder,
    this.classtypeplaceholder,
    this.typeplaceholder
  }
  else{
    this.routes.navigate(["/login"])
  }
}

  async pay() {
    let userForm ={
      'selectedFrom':this.bookForm.value.selectedfrom,
      'selectedTo':this.bookForm.value.selectedto,
      'passengers':this.bookForm.value.passengers,
      'selectedClass':this.bookForm.value.selectedclass,
      'selectedType':this.bookForm.value.selectedtype,
      'selectedPay':this.bookForm.value.selectedpay
    }
    let imageUrl = '';
  if (this.selectedPaymentMethod === 'gpay') {
    imageUrl = 'assets/images/gpay.jpg'; 
  }
  else if (this.selectedPaymentMethod === 'paytm') {
    imageUrl = 'assets/images/ptm1.jpg'; 
  }
    try {
      await Swal.fire({
        title: 'Payment Successful',
        text: 'Your ticket has been booked!',
        icon: 'success',
        imageUrl: imageUrl,
        imageWidth: 100,
        imageHeight: 100, 
        imageAlt: 'Custom image',
      });
  } catch (error) {
      await Swal.fire('Payment Error', 'Oops! Something went wrong. Please try again later.', 'error');
  } finally {
      this.isProcessingPayment = false;
  }
    this.bookingservice.postForm(userForm,this.calculatedFare).subscribe()
    this.routes.navigate(['show-ticket']);
    
  }
  EditBooking() {
    this.isButtonDisabled = false;
    this.isEditDisabled = true;
}

  async cancel() {
    try {
      await Swal.fire('Interrupted', 'Payment Failed.', 'info');
  } catch (error) {
      console.error('Error during cancellation:', error);
  }
    this.routes.navigate(['/'])
  }
  
  selectPaymentMethod(method: string): void {
    this.selectedPaymentMethod = method;
  }
}
