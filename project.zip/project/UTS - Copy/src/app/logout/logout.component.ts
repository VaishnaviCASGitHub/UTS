import { Component } from '@angular/core';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-logout',
  standalone: true,
  imports: [],
  templateUrl: './logout.component.html',
  styleUrl: './logout.component.css'
})
export class LogoutComponent {

  // Constructor
  constructor(private router:Router){}
  ngOnInit(): void {
    sessionStorage.setItem("loggedIn","false")
    sessionStorage.removeItem("uid")
    Swal.fire({
      icon: 'info',
      title: 'Logged Out',
      text: 'You have logged out.',
  });
    this.router.navigate(["/login"])
  }
}
