import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { Router, RouterLink, RouterOutlet } from '@angular/router';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { UsersService } from '../users.service';
import Swal from 'sweetalert2';
import { FooterComponent } from '../footer/footer.component';
 
@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, RouterOutlet, RouterLink, ReactiveFormsModule, FooterComponent],
  templateUrl: './register.component.html',
  styleUrl: './register.component.css'
})
export class RegisterComponent {
  showTooltip = false;
  errormessage:String="";
  registrationForm = new FormGroup({
    username: new FormControl('',[Validators.required, Validators.pattern("^[aA-zZ]+$")]),
    mail: new FormControl('', [Validators.required, Validators.pattern("^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$")]),
    password: new FormControl('', [Validators.required,Validators.pattern("^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$")]),
    cpassword: new FormControl('', [Validators.required,Validators.pattern("^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$")]),
    contactno: new FormControl('', Validators.required)
  })

  constructor(private usersservice: UsersService, private router:Router){}
  
  onSubmit(){
    const email=this.registrationForm.value.mail;
    let user:any= {
      username:this.registrationForm.value.username!,
      mail:this.registrationForm.value.mail!,
      password: this.registrationForm.value.password!,
      cpassword:this.registrationForm.value.cpassword!,
      contactno:this.registrationForm.value.contactno!,
      }
      this.usersservice.register(this.registrationForm.value).subscribe({
        next:(res)=>{
          this.registrationForm.reset();
          this.router.navigate(['/login']);
          Swal.fire({
            icon: 'success',
            title: `You have successfully registered!`,
            text: 'Thank you!',
        });
        },
        error:(err)=>{
          this.errormessage=err.error;
          console.log(err)
          Swal.fire({
            icon: 'error',
            title: 'Registration Failed',
            text: `${this.errormessage}`,
        });
        }
      })
    }
    checkPasswordRequirements() {
      const passwordControl = this.registrationForm.get('password');
      if (passwordControl) {
        const password: any = passwordControl.value;
        return {
          uppercase: /[A-Z]/.test(password),
          lowercase: /[a-z]/.test(password),
          digit: /\d/.test(password),
          specialChar: /[!@#$%^&*]/.test(password),
          minLength: password.length >= 8
        };
      }
      return null;
    }   
}
 