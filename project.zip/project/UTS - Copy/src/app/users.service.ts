import { Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http';
import {apiUrls} from './api.url';

@Injectable({
  providedIn: 'root'
})
export class UsersService {
  constructor(private http:HttpClient) { }

 // Register
  register(user:any){
    return this.http.post<any>(`${apiUrls.authServiceApi}register`, user, {withCredentials:true});
  }

  // Login 
  login(userLogin:any){
    return this.http.post<any>(`${apiUrls.authServiceApi}login`, userLogin,{withCredentials:true});
  }

 // isLoggedIn
  isLoggedIn():any{
    if(typeof(sessionStorage)!=='undefined'){
    let result = sessionStorage.getItem("loggedIn")
    if(result=='true'){
      return true
    }
    else{
    return false
  }
}
  }
}
  
