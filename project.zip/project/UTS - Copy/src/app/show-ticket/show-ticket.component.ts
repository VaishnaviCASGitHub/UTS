import { CommonModule } from '@angular/common';
import { Component, OnInit} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BookTicketComponent } from '../book-ticket/book-ticket.component';
import { BookingService } from '../booking.service';
import Swal from 'sweetalert2';
import { FooterComponent } from '../footer/footer.component';
import { QRCodeModule } from 'angularx-qrcode';

@Component({
  selector: 'app-show-ticket',
  standalone: true,
  imports: [BookTicketComponent, CommonModule,FormsModule, FooterComponent, QRCodeModule],
  templateUrl: './show-ticket.component.html',
  styleUrl: './show-ticket.component.css'
})
export class ShowTicketComponent implements OnInit{
 formList:any=[];
 isButtonDisabled = false;
 ticketId: any;
 showTooltip = false;
 showTable: boolean = false;
 currentTime: number = new Date().getHours();
 id:any=sessionStorage.getItem('uid');

 constructor(private bookingservice: BookingService){
  
 }
     
ngOnInit(): void {
  this.bookingservice.showForm().subscribe(
    (result:any)=>{
      this.formList=result.data
      console.log(this.formList)
      this.formList = result.data.sort((a: any, b: any) => {
        const dateA = new Date(a.createdAt);
        const dateB = new Date(b.createdAt);
        return dateB.getTime() - dateA.getTime();
    });
    }
  )
  
}

getCurrentTime(): Date {
  return new Date();
}

isEarlyMorning(): boolean {
  let now = new Date();
  let hours = now.getHours();
  return hours < 6;
}
isNight(): boolean {
  let now = new Date();
  let hours = now.getHours();
  return hours >= 22;
}
isMorning(): boolean {
  let now = new Date();
  let hours = now.getHours();
  return hours < 12;
}

isEvening(): boolean {
  let now = new Date();
  let hours = now.getHours();
  return hours >= 12;
}

isPastBooking(form: any): boolean {
  let now = new Date();
  let bookingDate = new Date(form.createdAt);
  let oneMonthAgo = new Date();
  oneMonthAgo.setMonth(now.getMonth() - 1);
  
  if (bookingDate.setHours(0,0,0,0) < oneMonthAgo.setHours(0,0,0,0)) {
    this.formList.splice(this.formList.indexOf(form), 1);
    return true;
  } else if (bookingDate.setHours(0,0,0,0) < now.setHours(0,0,0,0)) {
    return true;
  }
  return false;
}

onMouseEnter() {
  this.showTooltip = true;
  this.showTable = true;
}

onMouseLeave() {
  this.showTooltip = false;
  this.showTable = false;
}

cancel(form: any, ticketId:any, orderId:any, eMail:any){
  console.log(orderId)
  let now = new Date();
  let bookingTime = new Date(form.createdAt);
  let hoursDifference = Math.abs(now.getTime() - bookingTime.getTime()) / 3600000;
  if (hoursDifference <= 1) {
      form.isButtonDisabled = true;
      this.bookingservice.cancelShowTicket(orderId,eMail).subscribe(
        (result:any)=>{
                console.log(result)
                const index = this.formList.findIndex((ticket: any) => ticket._id === form._id);
          if (index !== -1) {
            this.formList[index] = result;
          }
      }
      )
      Swal.fire({
        icon: 'success',
        title: `Ticket has been cancelled`,
        text: 'Try new bookings!',
      })
    

  } else {
    Swal.fire({
      icon: 'info',
      title: `Sorry, only bookings made in the last 1 hour can be cancelled.`,
      text: 'Try new bookings!',
  });
  }
  
}
getQRData(form:any) {
  return `UTS TICKET DETAILS\nEmail: ${form.Email}\nTicket ID: ${form._id}\nFrom: ${form.From_Station}\nTo: ${form.To_Station}\nCount: ${form.Count}\nDate of Journey: ${form.createdAt}\nBooking Time: ${form.createdAt}\nClass: ${form.Class}\nType: ${form.Type}\nFare: Rs.${form.Fare}\nStatus: ${form.Status}`;
}

}