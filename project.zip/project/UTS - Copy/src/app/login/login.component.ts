import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, RouterLink, RouterModule, RouterOutlet } from '@angular/router';
import { UsersService } from '../users.service';
import Swal from 'sweetalert2';
import { FooterComponent } from '../footer/footer.component';
interface LoginResponse {
  status: number;
  message: string;
  data?: any; 
} 
@Component({
  selector: 'app-login',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule, RouterModule, RouterOutlet, RouterLink, FooterComponent],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
 // Login form group
  loginForm = new FormGroup({
  em: new FormControl('', [
    Validators.required,
    Validators.pattern('^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,4}$')
  ]),
  password: new FormControl('', [
    Validators.required,
    Validators.pattern('^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$')
  ])
});
 // Constructor
  constructor(private usersservice: UsersService, private router: Router){}
  ngOnInit(): void {
    if(this.usersservice.isLoggedIn()){
      this.router.navigate(['/'])
    }
  }
  errMsg:String="";
 // Onsubmit form
  onSubmit(){
    this.usersservice.login(this.loginForm.value).subscribe(
      {
        next:(res:LoginResponse)=>{
          if(res){
            let  uid:any=this.loginForm.value.em;
            sessionStorage.setItem("loggedIn","true"||"")
            sessionStorage.setItem("uid",uid ||"")
            const username = res.data.Name;
            Swal.fire({
        icon: 'success',
        title: `Welcome ${username}!`,
        text: 'You are now logged in.',
    });
            this.router.navigate(['/'])
            setTimeout(() => {
                alert('Your session is over');
          }, 15 * 60 * 1000);
          }
        },
        error:(err:any)=>{
            console.log(err)
            this.errMsg=err.error
            Swal.fire({
              icon: 'error',
              title: 'Login Failed',
              text: `${this.errMsg}`,
          });
            
        }
      }
      )
 
  }
}
 