import { Component } from '@angular/core';
import { BookTicketComponent } from '../book-ticket/book-ticket.component';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-footer',
  standalone: true,
  imports: [BookTicketComponent, CommonModule],
  templateUrl: './footer.component.html',
  styleUrl: './footer.component.css'
})
export class FooterComponent {
  title = 'app';
}
